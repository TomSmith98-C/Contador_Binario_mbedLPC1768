#include "mbed.h"

DigitalOut a(LED1);
DigitalOut b(LED2);
DigitalOut c(LED3);
DigitalOut d(LED4);

DigitalIn push(p5);

Serial pc(USBTX,USBRX);

//  A   B   C   D

int main() {
    while(1) {
        
        for(int i = 0; i <= 15; i++){
            switch(i){
                case 0: 
                    a = 0; b = 0; c = 0; d = 0; 
                    break; 
                case 1: 
                    a = 0; b = 0; c = 0; d = 1; 
                    break; 
                case 2: 
                    a = 0; b = 0; c = 1; d = 0; 
                    break; 
                case 3: 
                    a = 0; b = 0; c = 1; d = 1; 
                    break; 
                case 4: 
                    a = 0; b = 1; c = 0; d = 0; 
                    break; 
                case 5: 
                    a = 0; b = 1; c = 0; d = 1; 
                    break; 
                case 6: 
                    a = 0; b = 1; c = 1; d = 0; 
                    break; 
                case 7: 
                    a = 0; b = 1; c = 1; d = 1; 
                    break; 
                 case 8: 
                    a = 1; b = 0; c = 0; d = 0; 
                    break; 
                case 9: 
                    a = 1; b = 0; c = 0; d = 1; 
                    break; 
                case 10: 
                    a = 1; b = 0; c = 1; d = 0; 
                    break; 
                case 11: 
                    a = 1; b = 0; c = 1; d = 1; 
                    break; 
                case 12: 
                    a = 1; b = 1; c = 0; d = 0; 
                    break; 
                case 13: 
                    a = 1; b = 1; c = 0; d = 1; 
                    break; 
                case 14: 
                    a = 1; b = 1; c = 1; d = 0; 
                    break; 
                case 15: 
                    a = 1; b = 1; c = 1; d = 1; 
                    break; 
                default: 
                    i = 0; 
                    break;
                    pc.printf("Programa para lectura digital", push);
                }
            wait(1.0);
            }
    }
}
